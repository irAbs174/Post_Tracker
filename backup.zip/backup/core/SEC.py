# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-+li0e1b6!867%p^)!6cp&whl(c*!+rh=v0d*f_$ash$sems)d='
ALLOWED_HOSTS = [
    'unique.liara.run',
    'report.123kif.com',
    'report.123kif.ir',
    'www.report.123kif.com',
    'www.report.123kif.ir',
    '127.0.0.1'
    ]

CSRF_TRUSTED_ORIGINS = [
    'https://unique.liara.run',
    'https://report.123kif.com',
    'https://report.123kif.ir',
    'https://www.report.123kif.com',
    'https://www.report.123kif.ir',
    ]

# Production status (options: 'live' and 'dev')
production_status = 'live'

# Tracking post portal url configure
tracking_url = "https://tracking.post.ir"

# Sms api key configure
SMS_API = '4F53434B37317946416957716B6F7038544B685A784968763844347A366C7A413434454A722F68573938383D'

# Woocommerce api key configure
from woocommerce import API
WC_API = API(
    url="https://123kif.com",
    consumer_key="ck_1bceb9fb8193086220e30d369dca55248f89e4f9",
    consumer_secret="cs_13356ff3600db214712700c8703268efc6c6362d",
    version="wc/v3"
)
